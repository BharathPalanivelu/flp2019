package org.cap.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.model.LoginPojo;
import org.cap.service.ILoginService;
import org.cap.service.LoginServiceImpl;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private ILoginService loginService;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		loginService=new LoginServiceImpl();
		String userName=request.getParameter("userName");
		String userPwd=request.getParameter("userPwd");
		
		LoginPojo loginPojo=new LoginPojo(userName, userPwd);
		
		if(loginService.isValidLogin(loginPojo)) {
			//response.sendRedirect("pages/success.html");
			
			//Creating SessionContext
			HttpSession session= request.getSession();
			//Store new object in the sessionContext
			session.setAttribute("userName", loginPojo.getUserName());
			
			//request.getRequestDispatcher("SuccessServlet").forward(request, response);
			response.sendRedirect("SuccessServlet");
			/*request.getRequestDispatcher("pages/success.html")
					.include(request, response);*/
		}else {
			//response.sendRedirect("index.html");
			request.getRequestDispatcher("index.html")
				.forward(request, response);
		}
		
	}

}

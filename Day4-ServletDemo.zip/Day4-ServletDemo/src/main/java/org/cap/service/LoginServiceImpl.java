package org.cap.service;

import org.cap.dao.ILoginDao;
import org.cap.dao.LoginDaoImpl;
import org.cap.model.LoginPojo;

public class LoginServiceImpl implements ILoginService{
	
	private ILoginDao loginDao;
	
	public LoginServiceImpl() {
		loginDao=new LoginDaoImpl();
	}

	@Override
	public boolean isValidLogin(LoginPojo loginPojo) {
		/*if(loginPojo.getUserName().equals("tom") &&
				loginPojo.getUserPwd().equals("tom123"))*/
		if(loginDao.isValidLogin(loginPojo))
			return true;
		return false;
	}

}
